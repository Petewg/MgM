
Harbour MiniGUI IDE - FREEWARE
------------------------------

Copyright 2005-2015 Walter Formigoni <walter.formigoni@uol.com.br>

Source code for HMGS - MiniGUI - IDE can be downloaded at:
http://sourceforge.net/projects/hmgs-minigui/

   Parts of this project are based upon:

   MINIGUI - Harbour Win32 GUI Designer

   Copyright 2002 Roberto Lopez <harbourminigui@gmail.com>
   http://harbourminigui.googlepages.com/

   Harbour Minigui IDE

   (c)2004-2010 Roberto Lopez <harbourminigui@gmail.com>
   http://harbourminigui.googlepages.com/

============================================================================
This software is provided "as is", without any express or implied warranty.
In no event shall the author be held liable for any damages arising from the
use of this software.
============================================================================

Remarks:
--------

	- Harbour MiniGUI IDE is experimental code, so It could be 
	buggy / unstable and is not finished yet.

	- It reads / writes '.fmg' files (HMG form definition files) in
	'alternate syntax' (DEFINE...END) format.

	- To change a control position / size, you must select (click) it.
	Then you must click the right mouse button and select the action
	from the context menu. 

	- To edit a property or event, you must double click it (object 
	inspector window).
